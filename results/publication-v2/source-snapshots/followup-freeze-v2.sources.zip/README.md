# Quant

Auditable research for adaptive Bitcoin trend following. The implemented reference
is BTC/USDT **spot, 4-hour UTC candles, EMA 50/200, long/cash**, with a 20% annual
volatility target and maximum 100% exposure. The adaptive policy selects among
25/100, 50/200 and 100/400 using trailing, cost-adjusted shadow portfolios.

This repository implements data auditing, causal backtests, comparison reports,
research-attempt logging, protocol freezes and controlled statistical experiments.
It has no exchange order submission interface.

## Run locally

Install [uv](https://docs.astral.sh/uv/getting-started/installation/) and Python 3.13,
then run from this repository:

```sh
uv sync --locked
uv run --locked quant --help
uv run --locked pytest -q
```

Use a deterministic **synthetic** fixture to exercise the pipeline:

```sh
uv run --locked quant demo-data --output data/demo-4h.csv
uv run --locked quant run --data data/demo-4h.csv --phase development
uv run --locked quant evidence --output runs/evidence.json
uv run --locked quant ledger
```

Each backtest writes a unique `runs/<run-id>/` directory containing a report,
equity and trades, selector decisions, provenance, effective settings and a chart.
Synthetic results test software behavior and say nothing about Bitcoin returns.
Dataset and evidence outputs refuse overwrites; choose a new name to repeat them.

## Public historical data

The strict importer verifies archive checksums and rejects malformed candles or
gaps. This explicitly audited alternative preserves raw files, records excluded
rows and permits disclosed gaps:

```sh
uv run --locked quant fetch --end 2024-12-31 --output data/btc-4h-through-2024.csv --allow-gaps --quarantine-invalid
uv run --locked quant audit --data data/btc-4h-through-2024.csv --allow-gaps
uv run --locked quant run --data data/btc-4h-through-2024.csv --phase selection --allow-gaps
```

The audited snapshot contained 19 quarantined rows and 36 missing bars. Resetting
features after gaps leaves only 758 comparable candles in late 2024; development
evaluation correctly refuses insufficient history. The adaptive policy matched
the fixed strategy, and the sample was too short for the prespecified bootstrap.
**An adaptive trading edge has not been established.**

## Completed baseline research and current limits

The publication study extends the audited inputs through October 20, 2026,
with 24 known-truth simulation cases and six retrospective market cases. The
primary four-hour adaptive selector makes no evaluation-window switches and
matches the fixed benchmark's 2.6067% return. Hourly and daily checks do not
establish material improvement. The original 2024-only result above is retained
as an earlier implementation milestone, not the full current evaluation.

Use the [reproduction guide](docs/publication/REPRODUCE.md) to verify results,
rebuild the paper, or replay exact frozen computations. A separately specified
follow-up is addressing stronger statistical comparators and temporal cost
coherence. The [completion audit](docs/publication/STATUS.md) remains open.

## Research and controls

- [Active publication project](docs/publication/README.md): registered study design,
  independent mathematical review, paired-cost methods and remaining publication gates.
- [Implementation and operating guide](docs/implementation.md): timing, accounting,
  gap handling, statistical limits, ledger and reserved-evaluation workflow.
- [Earlier validation results](docs/validation.md): the 123-test implementation
  milestone, initial data coverage and fingerprints; newer publication evidence
  is recorded in the active project rather than rewriting this history.
- [Exact protocol](configs/research/btc-trend.toml) and
  [Bitcoin research specification](docs/research/bitcoin-trend-bot.md).
- [Frontier research dossier](docs/README.md): the selected question, nearest work,
  novelty risks and further experiments.

Raw data, runtime ledgers and generated reports stay in ignored `data/` and
`runs/` directories. Preserve them when sharing or archiving an experiment.
