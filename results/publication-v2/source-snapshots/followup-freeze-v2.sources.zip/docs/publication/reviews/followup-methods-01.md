# Independent follow-up methods review 01

Reviewed 2026-10-22, before substantive v2 outcomes. Scope: `src/quant/followup.py`, `tests/test_followup.py`, `configs/research/followup-study-v2.json`, `docs/publication/followup-protocol-v2.md`, and the inherited calibration, mixture, summary, snapshot and ledger helpers. No source or protocol was edited by this reviewer. Only this review was written. No substantive simulation, historical-return evaluation or baseline-replay outcome inspection was performed.

## Disposition

No material mathematical or implementation blocker remains for freezing and starting the specified 25-case diagnostic study at the fingerprints below. This is a scoped pre-outcome review, not certification of a completed study, publication novelty, arbitrary uses of the primitive functions or a financial trading guarantee. The actual substantive run, its manifests, world-level results and interpretation require a separate outcome audit.

The follow-up has a defensible purpose: separate losses from the choice of the base sequential method, local cost pessimism and discarding one common cost coefficient across time. It uses established inference constructions. It must remain separately labeled as specified after all v1 outcomes; it cannot retroactively strengthen the v1 registration or market evidence.

## Mathematical conditions and proofs

### Fixed linear mixtures

Let `D_i` be the true materiality-adjusted paired utility, `mu_i=E[D_i|F_(i-1)]`, and `F` contain the actual past decision/calibration information and the oracle information needed for the null. For the prefix-weak null require `sum_(i<=n) mu_i<=0` almost surely at every prefix. Fixed nonnegative lambdas and mixture weights are chosen before the stream begins. Here `|D_i|<=1` and every linear lambda is below one.

For a fixed lambda, the positive process

```
R_n = product_(i<=n) (1+lambda*D_i)/(1+lambda*mu_i)
```

is a martingale. Its denominator product is at most `exp(lambda*sum mu_i)<=1`. Consequently `product(1+lambda*D_i)<=R_n` at every prefix. A mixture of these fixed components is dominated by a test martingale. This is the existing v1 weak-prefix argument, not a new contribution or permission to refit the component lambdas adaptively.

### Predictably centered empirical Bernstein

For `|D_i|<=1`, predictable `gamma_i in [-1,1]`, `0<=lambda<1/2` and

```
psi(lambda) = (-log(1-2*lambda)-2*lambda)/4,
```

the implemented true-parameter log evidence is `sum[lambda*D_i-psi(lambda)*(D_i-gamma_i)^2]`. Its normalization and admissible lambdas agree with the `c=2` specialization of Choe and Ramdas, Theorems 2–3. Their weak-null result directly covers the fixed-component construction. [Primary source, version 4](https://arxiv.org/html/2110.00115v4#S4.SS3.SSS3).

An explicit check of the condition is useful. For `z=D_i-gamma_i>=-2`, the standard bounded-score exponential inequality gives

```
exp(lambda*z-psi(lambda)*z^2) <= 1+lambda*z.
```

Taking conditional expectations and multiplying by `exp(lambda*(gamma_i-mu_i))` bounds the expected centered exponential factor by `exp(-s)*(1+s)<=1`, where `s=lambda*(mu_i-gamma_i)>-1`. Therefore

```
N_n = exp(sum[lambda*(D_i-mu_i)-psi(lambda)*(D_i-gamma_i)^2])
```

is a test supermartingale. The true-parameter product is at most `N_n` under the prefix-weak null. This proof permits the implemented predictable centers and fixed mixtures; it does not justify arbitrary outcome-adaptive lambdas under that null.

The implementation correctly computes each center from previously observed plugin utilities using the coefficient sample mean available when each past outcome was issued. It freezes that center for the historical contribution. It does not retrospectively recompute old centers using later calibration information. All EB comparators use this same center, fixed grid and normalization within a case.

### Local infima and coherent profiling

Write `A_i=G_i-m`, `d_i=qA_i-qR_i` and `D_i(theta)=A_i-d_i*theta`. On simultaneous coverage, the true utility lies in the joint interval and in the larger separately bounded interval. The EB factor is nonmonotone in utility. The implementation correctly takes the smaller factor at the two utility endpoints, rather than inserting only the lower utility.

For the coherent method the sum of log factors is a concave quadratic in one fixed theta. The five sufficient sums in the source reproduce

```
lambda*(sum A-theta*sum d)
 - psi(lambda)*(sum(A-gamma)^2
                -2*theta*sum((A-gamma)*d)+theta^2*sum d^2).
```

Its infimum over a nonempty scalar interval is the smaller endpoint value. The code profiles each component separately and then mixes. It does not incorrectly assert that the minimum of the entire mixture must be at an endpoint.

If the current set is contained in every earlier set, evaluating the entire historical product at any current theta is at least the product of earlier per-label minima. Profiling and mixing preserve coherent evidence at least joint-local evidence. The source checks this algebraic comparison with a floating-point tolerance and excludes permanently suspended conflict worlds. This comparison does not require coverage, provided the intervals are nonempty and nested. Neither this dominance nor earlier discovery implies higher subsequent deployment utility.

The construction requires one theta throughout the history and centers fixed at their actual past values. It does not rerun a hypothetical policy for each theta, allow a separate adverse coefficient per label, or establish a model for realized venue slippage. The general nuisance-infimum/confidence-set principle and this computational specialization were assessed in [coherent-cost-direction-01.md](coherent-cost-direction-01.md); no strong new-method novelty claim is supported here.

### Adaptive betting has a different null

The raw-score rule `clip(sum x/sum x^2,0,.8)` is the stated one-sided aGRAPA approximation, after rescaling bounded observations to test zero mean. It follows the approximate score equation in Waudby-Smith and Ramdas, Appendix B.3. The declared initial stake and zero-denominator convention are implementation choices; this is not a reproduction of every confidence-set construction or regularized estimate in that paper. [Primary source, version 6](https://arxiv.org/html/2010.09686v6#A2.SS3).

Under the strong conditional null, any implemented stake is predictable and in `[0,.8]`; the true linear factor has conditional expectation at most one. On coverage, its lower-proxy factor is no larger than the true factor **with that same actual stake**. The dominating latent shadow process for joint aGRAPA uses the bets fitted from the joint proxy; it is not necessarily the separately fitted oracle-aGRAPA comparator. Thus the source and protocol correctly avoid claiming oracle/joint/separate pathwise dominance after fitting different bets.

The deterministic negative-then-positive prefix example shows why arbitrary predictable betting is unsupported under the weak-prefix null. The additional case labels all three aGRAPA methods unsupported. Its empirical rejection frequency must not be used to validate them for that null. In the ordinary factorial cases the null streams satisfy the stronger conditional null, so all methods can be compared there with their stated guarantees.

### Coverage composition and multiplicity

For each method, on the single global event that the cost interval contains the fixed coefficient at every used issue time, its observable cost evidence is bounded by its applicable latent valid process. Hence

```
P(any null-stream crossing)
 <= P(any corresponding latent crossing)+P(global cost-coverage failure)
 <= 10*(.04/10)+.01 = .05.
```

This is an unconditional event-inclusion argument; it never conditions the latent process on successful coverage. The observable cost-profile process need not itself be an exact e-process when coverage can fail. The one shared cost confidence sequence is charged once for all streams in a comparator family. The protocol now explicitly states that this is a separate ten-stream FWER bound **for each comparator**. It is not a 5% bound for the union over ten methods or for choosing a favorable method after comparison. Approximate Monte Carlo intervals across many endpoints are likewise not simultaneous discovery guarantees.

Oracle comparators retain the same conservative test thresholds even though their correctness needs no cost-envelope allocation. That is a declared matched-comparison choice, not a claim that an oracle requires delta.

## Generator and information timing

The 24 factorial cells and one weak-prefix diagnostic are validated before use. The first stream is the only alternative in the positive-effect factorial cells; other streams have conditional mean zero. Every stream is null in zero-effect cells and in the prefix-weak case. The volatility depends on time and the previous common sign; fresh common and individual fair signs have conditional mean zero. Cross-stream dependence therefore does not invalidate the per-stream arguments or union bound. Worlds remain independent.

The specified deterministic support bound is conservative and below one. For example the actual sigma is at most `.55`; bounding its value by `.65`, adding the largest `.06` drift, `.4*.08` offset and `.8*.2` separate-cost term yields the stated `.902<1`. Affine counterfactual extrema occur at support endpoints. The runtime sample maximum is only a diagnostic and is not the proof of boundedness. No utility clipping is performed.

Turnover, centers, aGRAPA stakes and used intervals are formed before the current shocks. Evidence is updated once per non-overlapping current label. A new calibration draw is revealed after that update and can affect only the next label. The current interval in whole-history profiling may revise the uncertainty charged to old outcomes; it does not reveal a future outcome or revise the previously chosen centers or trading policies.

Selected streams earn the current latent utility before the current evidence crossing is processed. A first discovery therefore activates only on the next label. Ties use the lowest index, and the first selection remains fixed. Final-label discoveries earn no subsequent utility. The additive utility is already materiality-adjusted; it is neither compounded funded P&L nor a market performance estimate.

Outcome and calibration RNGs are separate, and common seeds across cells intentionally align innovations by world index. Static cells still consume calibration draws, preserving the pairing. Factorial cells and streams must not be counted as independent replications. Comparisons of contracting versus static cost information also change plugin-center quality and fitted adaptive stakes; only matched within-cell comparisons isolate the corresponding profiling operation cleanly.

The implementation now distinguishes conflicts and coverage failures of intervals actually used for testing from a conflict created by the final unused post-horizon calibration update. Empty intersections permanently suppress new cost-based discoveries; they are not treated as infinite evidence. Already earned discoveries are not erased after a later conflict. These conventions are appropriate for the crossing guarantee.

## Monte Carlo outputs, provenance and residual limits

The saved arrays retain per-method/world/stream hits and first crossings, selected streams, world-level utility, truth masks, used coverage/conflict indicators, final unused-conflict indicators and final component values. Case summaries use world-level family events. First-stream rejection is neutrally named in null and weak-null cells. The restricted detection time is `min(first crossing,T)`, with noncrossings and final-label crossings sharing the horizon value; the original sentinel and hits remain available to identify censoring.

Wilson intervals are used for binary error/rejection proportions. Signed paired rejection differences and utility differences use world-level paired normal approximations. Degenerate normal intervals are unavailable rather than represented as certainty. These are approximate, unadjusted simulation uncertainty summaries. A zero sampled error count is not a proof of zero type-I error.

The inherited calibration interval uses all-n `n^-2` spending while the follow-up first queries n=32. Its Hoeffding union bound over used times is at most `delta*(6/pi^2)*sum_(n>=32)1/n^2`, approximately `1.93e-4`, already much smaller than the reserved `.01`; the static cell uses just the n=32 slice. This conservatism is valid but limits conclusions about calibration efficiency or optimal power. The registered design should be preserved, and later reporting should separate this limitation from paired-cost geometry. No optimal base method, grid, confidence sequence or universal method dominance is established.

The source reports named persistent array storage, including calibration totals and fixed grids, rather than process peak memory or all transient allocation. Five-sum state is constant in horizon length at fixed world/stream/component dimensions. That computational statement is supported by the code; benchmark timings remain empirical machine-dependent measurements.

The freeze gate checks source/specification fingerprints, the source ZIP, protocol/review document hashes and Python/NumPy versions. The current run manifest attaches the actual sealed freeze payload and file digest plus runtime. Separate parent/case ledger attempts preserve failures; output paths cannot overwrite prior attempts. A partial manifest contains only completed cases and has no completion timestamp. Invalid freeze attempts now begin their ledger record before specification parsing. Successful execution still needs to be demonstrated after the freeze. No v2 full reproduction/export path has been certified by this review.

The primitive functions are not a general validated inference API: arbitrary caller-provided supports, lambdas, shapes or statistics are not comprehensively rejected. This assessment concerns the fixed validated runner and its stated bounded generator. Reusing the primitives outside that scope requires separate validation and assumptions.

Novelty and publication readiness remain open. A diagnostic empirical result may be useful, particularly if matched temporal profiling has material gains after including active variance-adaptive comparators. Such gains have not yet been established by this review. The current theorem ingredients and scalar optimization identities are established, and no claim about exploitable Bitcoin alpha follows from synthetic evidence.

## Verification performed

At the reviewed source, the focused command was:

```
.venv/Scripts/python.exe -m pytest tests/test_followup.py -q --basetemp=runs/pytest-agent-followup-final-2
```

All 10 tests passed. They cover the registered factorial, nonmonotone EB endpoint treatment, five-sum equality and profiling dominance, bounded prior-only aGRAPA, deterministic smoke/truth/timing, weak-null labeling, unfrozen-run refusal, empty-intersection suspension, failed-case ledger preservation and final-unused calibration conflict separation.

Additional reviewer checks, without changing tests or source, verified 49,500 one-step centered-EB conditional-mgf inequalities across bounded two-point laws, centers and the fixed lambda grid; moving nested-interval profile equality against direct whole-path evaluation; and a forced first-label discovery earning exactly labels 2 onward in mechanical smoke. These finite checks are implementation diagnostics, not mathematical proofs or substantive power estimates. No natural substantive v2 endpoints were viewed.

## Reviewed fingerprints

SHA-256 of the final reviewed files:

| File | SHA-256 |
| --- | --- |
| `src/quant/followup.py` | `cc4e0d259b15bee981a10ae356bb898674b86c17821baf3333659967aa87ae3e` |
| `tests/test_followup.py` | `47d420858a776bc13d92a0a1a0aadfb90c517fc418078e8e2247a468dd7e134e` |
| `configs/research/followup-study-v2.json` | `e683706368446fe27d019c6b0984a35ded9938f80e689699937dc70b81d24211` |
| `docs/publication/followup-protocol-v2.md` | `f0ea1c6150cc5d51e468331797955d3410cbcde4a19a3e16385f4812bbbf6c28` |
| `src/quant/publication.py` | `327ddf07481c9af63b4dea432aca675cff4387dd33fcba997db4b2fb63bd770a` |

The subsequent freeze must include this review and the actual full source archive. Later source/protocol changes require a disclosed new fingerprint or review amendment; they are not silently covered by this disposition.
