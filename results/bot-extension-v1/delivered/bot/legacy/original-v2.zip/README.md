# BTC Trend Bot (v2)

Long-only Bitcoin trend-following bot with volatility targeting. It checks once a day and holds anywhere from 0% to 100% of the account in BTC.

## Files
- `trend_bot.py` — **the v2 bot** (strategy, backtest, paper trading). Run this one.
- `mr_bot.py` — the old v1 mean reversion bot. v2 imports its broker and data code from here, so keep both files in the same folder.
- `requirements.txt` — `pip install -r requirements.txt`

## How v2 decides (once a day, after the UTC daily close)
1. **Trend score:** the fraction of the 40/50/60/80/100/150-day moving averages that price is above (0 to 1).
2. **Volatility scaler:** min(1, 40% ÷ last 30 days' annualized volatility). In wild markets it holds less.
3. **Target = trend score × volatility scaler.** It trades only if the current holding is more than 15 percentage points off target, which saves fees.

## Run it
```bash
python trend_bot.py backtest --days 1500        # history from Kraken (or --data file.csv)
python trend_bot.py sim                         # paper trading on live prices, no account needed
python trend_bot.py alpaca                      # Alpaca paper account (set ALPACA_API_KEY / ALPACA_API_SECRET)
python trend_bot.py binance                     # Binance Spot Testnet (set BINANCE_TESTNET_KEY / BINANCE_TESTNET_SECRET)
```
Broker modes are hard-wired to paper/testnet. Paper modes log every day to `v2_log.csv`.

## Results (details in research/RESULTS.md)
- **Walk-forward test, 2020–2025:** Sharpe 1.40 vs 1.09 for buy & hold; worst drop −41% vs −77%.
- **Locked final year, Oct 2025 – Sep 2026, tested once:** +7.9% vs −26.7% for buy & hold.
- **Expect it to trail buy & hold in strong bull runs.** Its edge is losing less in crashes.

## Research folder
The code behind the results. To reproduce them:
```bash
cd research
python get_data.py      # downloads ~8 years of hourly BTC from Binance's public archive
python run_all.py       # all 6 strategy families, walk-forward  (--low for lower fees)
python checks.py        # fake-data, look-ahead and bootstrap checks
python ml.py            # the machine-learning attempt
```
Results are in `RESULTS.md`, the written-down choice in `PREREGISTRATION.md`, every experiment in `EXPERIMENT_LEDGER.md`, and the live forward test in `forward_log.md`.
