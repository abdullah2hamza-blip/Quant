# Focused implementation review: cost evidence primitives 01

Review date: October 21, 2026. Scope: `src/quant/cost_evidence.py` and `tests/test_cost_evidence.py`, compared with [mathematical-design-01.md](mathematical-design-01.md). No source or test files were changed by this reviewer. The substantive simulation runner and its information flow have not yet been reviewed.

## Disposition

The reviewed formulas and issue/maturity state transitions implement the intended primitives correctly under their documented assumptions. Two material issues identified during review were corrected by the main implementer and independently rechecked. There is no outstanding critical implementation finding in the final reviewed primitive snapshot.

The final snapshot reviewed had SHA-256:

| File | SHA-256 |
|---|---|
| `src/quant/cost_evidence.py` | `f150743b4c0e50fe0aa616ef9d48edbec70570622d0bf17d0303654a1199969e` |
| `tests/test_cost_evidence.py` | `b8fde30d4c36526b9a414779066f8b919ce5a6d5a10f135c2fdf245fae491c45` |

These hashes identify the precise reviewed content, not later revisions. Passing primitive tests does not establish calibrated market cost coverage, a valid simulation law or publication readiness.

## Findings resolved during review

### Invalid comparators previously inherited a guarantee label

The first version of `CostEvidenceStream.observe` returned the same latent-domination guarantee string for `joint`, `separate`, `plugin` and `symmetric_upper`. The latter two proxies need not be lower bounds even when the interval covers perfectly; that metadata could falsely characterize deliberately invalid baselines as controlled methods.

The corrected implementation emits `none: deliberately unguaranteed cost comparator; lower-proxy domination is not established` for `plugin` and `symmetric_upper`, and retains the qualified coverage-budget text for `joint` and `separate`. Both invalid modes have a direct regression test. The reporting issue is resolved in the reviewed snapshot. Downstream plots and tables must retain this distinction rather than grouping every `CostEvidenceStream` as guaranteed.

### The allegedly fixed mixture grid was aliased and mutable

The original constructor stored `np.asarray(grid)` directly. A caller-owned NumPy array could therefore change a stream's mixture grid after birth, violating the fixed-mixture claim without an explicit change to the stream. Refitting stakes can invalidate the prefix-weak interpretation; a predictable change is not enough to preserve that interpretation.

The corrected constructor copies the grid and makes the backing array read-only. The public grid property returns a read-only view. Public `alpha`, `bound`, `grid`, `mode`, `proxy` and `birth_time` properties cannot be reassigned. Regression tests check external-array mutation, element mutation and public configuration reassignment. An independent caller-array mutation check confirmed that modifying the original array no longer changes the stream's evidence grid. This issue is resolved for the normal supported API. It is not a security boundary against a caller deliberately editing private attributes or evidence state.

## Formula and assumption review

### Known latent bound and proxy projection

`observe` computes `normalized=clip(raw_proxy/bound,-1,1)`. This is correct for a prespecified latent utility `D in [-B,B]`: on the joint coverage event, `L<=D` implies `clip(L,-B,B)<=D`. The floor matters when pessimistic costs make `L<-B`. It prevents negative linear factors while preserving pathwise domination.

The projection does not verify the latent support assumption. A clipped proxy cannot turn an unbounded target into a bounded one without changing the estimand. The source comment correctly states that the known bound is on latent `D`, not merely on the proxy. The existing test checks a proxy far below the lower bound. An additional independent calculation checked a nonunit bound `B=2`.

### Fixed-mixture updates

The linear update `log1p(lambda*normalized)` correctly accumulates the log of each component product; `log_mixture` computes the log of their **equal-weight arithmetic mixture** by log-sum-exp. It is not averaging component logs. Grid values strictly inside `(0,1)` keep linear factors strictly positive on the projected domain.

The Hoeffding update is

\[
\lambda D/B-\lambda^2/2,
\]

after lower-proxy projection. This is the correct normalized version of `tilt*D - tilt^2*B^2/2` with `tilt=lambda/B`, because the latent range length is `2B`. Summing the per-trial penalty yields `n*lambda^2/2`; no factor-of-four error is present.

The implementation's `linear` docstring currently emphasizes the strong conditional null, whereas the fixed-lambda mixture also supports the prefix-weak null by the ratio-martingale argument in the design review's addendum. The existing wording is conservative rather than an invalid claim. If the study uses the stronger interpretation, its protocol, method labels and manuscript should state this additional proof and retain the fixed-grid restrictions. A linear product with arbitrary adaptively refitted stakes has only the earlier strong-null result without a new argument.

The pathwise joint-versus-separate wealth test is meaningful because both methods use the same fixed grid, equal weights and bound. It does not support wealth domination between independently optimized adaptive betting rules.

### Cost calibration confidence sequence

For `n>=1`, `bounded_cost_interval` spends

\[
\delta_n=6\delta/(\pi^2n^2)
\]

and uses radius

\[
r_n=c\sqrt{\log(2/\delta_n)/(2n)}
\]

for observations in `[0,c]`. The code's simplified logarithm `log(pi^2/(3*delta))+2*log(n)` is algebraically identical. Two-sided conditional Hoeffding bounds each time's failure by `delta_n`, and summing over all positive `n` bounds any failure by `delta`. Clipping the interval to `[0,c]` is valid under the support/mean model. The zero-observation interval is the full support and consumes no extra failure probability.

The source explicitly requires a fixed conditional mean `theta` given the complete preceding game information and requires the caller to validate individual observations. Checking only `0<=total<=n*c` cannot establish those assumptions. No test should suggest otherwise. Sampling/calibration selection and its availability timestamps remain obligations of the runner.

This is a conservative confidence sequence obtained by time spending, not a tight empirical-Bernstein sequence. Its width may substantially reduce power; that is a design feature to measure, not an implementation defect. It is an interval for a common mean coefficient, not each future realized slippage.

### Paired cost geometry

The joint expression subtracts `max((qA-qR)*lower,(qA-qR)*upper)`, which chooses the correct endpoint for either sign. The separate expression subtracts `qA*upper` and adds `qR*lower`. Their difference equals `min(qA,qR)*(upper-lower)` for nonnegative turnovers. Tests cover both signs, zero turnover and equal turnover, and check domination over parameter values throughout the interval.

The plugin and symmetric-upper expressions implement the intended deliberately unguaranteed comparators. The primitive does not establish that a common linear coefficient applies economically; its docstring says so. Exact Bitcoin accounting should remain separate from this synthetic mean-cost model.

### Error allocation

`test_level` reserves one global `delta_cost` from `alpha_family`. Fixed families receive `(alpha_family-delta_cost)/H`. Adaptive births receive `(alpha_family-delta_cost)/(j*(j+1))`, whose infinite sum is the remaining test budget. Validation excludes zero/negative birth indices, invalid probabilities and fixed-family indices above `H`.

This implements allocation amounts, not a stateful family registry. The caller must use each birth index once, freeze the chosen allocation scheme, retain failed/abandoned births and avoid charging one global coverage budget for several unrelated confidence sequences. If all candidates share one valid confidence sequence for the same common parameter, charging it once is appropriate. A later runner must ensure the actual interval's delta and model identity agree with that budget; a `CostInterval` by itself does not enforce that association.

## Timing and state review

The primitive enforces the intended conservative non-overlapping schedule:

- A stream starts at its registered birth time, and a first issue cannot be backdated before birth.
- Only one pending trial is permitted. A second issue is rejected even if the previous outcome has matured but has not yet been observed.
- Maturity must be strictly after issue.
- The cost interval's declared availability must be no later than issue, and the frozen `IssuedTrial` retains that interval, turnover, materiality and plugin estimate.
- Observation before maturity is rejected. Observation updates one label and clears the pending trial, preventing double scoring.
- If an outcome is observed late, the next issue cannot be backdated before that actual observation time.
- A next issue at the same timestamp as a just-observed maturity is allowed. The runner must order the observation before the new decision at that timestamp.

The first-crossing time remains recorded after a crossing. The separate `crossed` flag describes the current wealth's relation to its threshold; it can become false after losses. Discovery accounting should use an ever-crossed/first-crossing convention and not accidentally erase a prior rejection when wealth falls.

The stream cannot determine whether its caller already inspected a current outcome, a future market array, a hidden parameter or a cost interval with a false availability label. It also cannot check the gross outcome's association with the pending trial. Those are substantive runner-review obligations. The explicit timing API is useful discipline, not a proof of filtration compliance on its own.

## Verification performed

The initial focused suite passed 22 tests. After the two fixes and regression additions, the reviewed suite passed:

```powershell
.\.venv\Scripts\python.exe -m pytest tests/test_cost_evidence.py --basetemp=runs/pytest-agent-cost-primitives-v2 -q
```

Result: **25 passed in 1.08 seconds**. All tests were local; no network, exchange or financial dataset was used.

A separate ephemeral review calculation enumerated all 64 six-step outcome paths with `D_i in {-2,+2}`, bound `B=2`, positive probabilities alternating `.25,.75`, and grid `(.1,.3,.8)`. The conditional means alternate `-1,+1`, so the prefix-weak null holds but the strong null does not. For every prefix, it compared the implementation's linear mixture to the null-law ratio-martingale mixture and its Hoeffding mixture to the centered Hoeffding supermartingale mixture.

| Independent check | Result |
|---|---:|
| Expected terminal ratio-martingale mixture | `1.0000000000000002` |
| Maximum positive linear domination error | `0` |
| Maximum positive Hoeffding domination error | `4.440892098500626e-16` |

The calculation checks arithmetic and the nonunit-bound convention; it is not an empirical proof of universal validity. The analytical proofs remain necessary.

## Remaining targeted validation before substantive runs

No further primitive formula change is required by this review. The following additions would strengthen the integration checks as the runner is written:

1. Preserve a permanent test of a prefix-weak but not strong generating law and the ratio-martingale domination argument. Include a nonunit latent bound. This is more informative than only mirroring the one-step update formula.
2. Exercise a crossing followed by a decline and confirm that family-level discovery accounting preserves the first rejection.
3. Verify issue/maturity ordering, hidden parameter access and per-observation calibration support through the actual simulator interfaces, not just `CostEvidenceStream` calls.
4. Record actual simultaneous calibration failure, latent crossings and observed crossings separately, and check the pathwise crossing inclusion used by the theorem.
5. Confirm that fixed and adaptive birth indices are never reused, and that one global confidence-sequence budget is not silently reused for different cost models.

The fixed-linear prefix-weak refinement and nearest-primary-literature search are recorded in the addendum to the design review. They are an elementary application of mean-centered betting and a multiplicative compensator. No originality or publication-readiness conclusion follows from these primitives passing review.
