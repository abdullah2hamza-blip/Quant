# Independent simulation-runner review 01

Review date: October 21, 2026. Scope: `src/quant/publication.py`, its focused tests, the cost-evidence primitives and deterministic counterexamples, and the registered synthetic specification/protocol. Only this review file was written by the reviewer. No substantive simulation was run.

## Disposition and reviewed snapshot

No unresolved material implementation defect was found in the final reviewed runner for the **24 currently registered cases**. Reporting issues found during review were corrected and independently checked. The implementation is consistent with the qualified mathematical results in [mathematical-design-01.md](mathematical-design-01.md), including its fixed-linear prefix-weak addendum.

One information-set declaration must be explicit before freezing: the turnover rule accesses the previous common shock. The synthetic game must declare that shock observable at its maturity, or replace that policy input with observable score history. Access is to a past, matured shock, so no current/future-outcome leak was found; the distinction is between actual observable past and oracle-only past. This is a model/documentation condition, not an asserted current-label leak.

The reviewed snapshot has these SHA-256 hashes:

| File | SHA-256 |
|---|---|
| `src/quant/publication.py` | `ba8fe9ff9d25d96ae8b6edaf7e4c92a85ea5aba0a2a40c4b277974bb29e6d58b` |
| `src/quant/cost_evidence.py` | `0264ba9749001911901592a0723898ed20d5933de5a471dbcb23bbe0a11051db` |
| `tests/test_publication.py` | `1c563b6c52f495addf2c6722d68761e233cdbd85d62a41de39c1c073f3647389` |
| `tests/test_cost_evidence.py` | `6543df716aeb24a8a545ef7b88f35dc84b47425eadee4d9ec9283ac2933fe0d8` |
| `configs/research/publication-study-v1.json` | `ee88dff71cc989114b79a616ab1a3e95abc7be2ded867093060531bd7814d625` |

These identify the code and tests actually reread and executed. Additional tests or documentation clarifications after this review must enter the eventual freeze's final hashes. A substantive algorithm change needs corresponding review; the existence of a review file does not certify arbitrary later source.

## Findings resolved before this report

### Primary paired comparison was mislabeled in null cases

The initial result key called every first-stream hit difference a power difference, including global-null worlds. It is now `first_stream_joint_minus_separate_rejection_rate`, a neutral label. In cases where that first stream is alternative, it can be interpreted as a power gain; in null cases it is a difference in false-rejection probability.

The first-stream index is not always a generic randomly selected candidate: in adaptive-birth cases, the first prescreen is tied at zero and deterministic argmax chooses pool index zero. Subsequent births use accumulated observable prescreens. This tie rule is deterministic and reproducible, but must not be described as having performed informative selection at time zero.

### Primary paired Monte Carlo intervals could collapse at zero events

The original paired comparison used a normal interval for the world-level hit difference. Because joint discovery pathwise contains separate discovery, this difference is binary: a world either has a joint-only discovery or has no difference. A sample with no discordant worlds produced an unjustified zero-width normal interval.

The final implementation asserts nesting and uses a Wilson interval on the joint-only hit indicator. Its upper endpoint remains positive when no discordant worlds are observed. The primary paired comparison therefore preserves Monte Carlo uncertainty at zero observed gains.

Generic normal intervals for utility and restricted time also previously collapsed on constant samples. They now return a null interval, an explicit `sample_degenerate` flag and a caveat that empirical zero standard error does not establish zero uncertainty. Nondegenerate normal intervals remain approximate Monte Carlo intervals, not finite-sample concentration guarantees. Downstream tables must display unavailable intervals rather than convert null to zero.

### Detection-time origin was ambiguous

The output now explicitly states that detection times are calendar steps from the study origin, not elapsed time since each adaptive birth. This matches the implementation. It should not be relabeled as post-birth detection delay in figures or the manuscript.

### Prescreen-reuse counterexample and actual pointwise false rejection were missing

The protocol promised an outcome-reuse diagnostic. The final `counterexamples()` now supplies one: independently search a batch of null labels, choose the maximum after inspection and reuse the selected outcome as fresh evidence. The selected-label mean, expected invalid factor and a false-rejection lower bound are correct for that example.

The pointwise-envelope diagnostic now also gives the actual finite-horizon false-rejection probability for its stated process, rather than only the probability of any envelope failure. A proxy of one on independent failures and zero otherwise, with stake `.8`, crosses after six failures at level `.05`; the recorded probability is the corresponding binomial upper tail. These are deterministic analytic diagnostics, not empirical results from the valid simulator.

## 1. Generator truth and the conditional null

For each world and trial, the runner creates a fresh common Rademacher shock and independent candidate-specific Rademacher shocks. Conditional on all past state, the common and individual shocks have mean zero. Noise is

\[
\sigma_t(.6C_t+.4I_{k,t}),
\]

where `sigma_t` depends only on calendar time and the previous matured common shock. Its range is `[.2,.55]`; the registered effect is at most `.1`. Therefore generated latent utility is bounded by `.65` in absolute value, strictly within the registered evidence bound `B=1`. The runtime bound check is an additional diagnostic; validity comes from the generating law, not from observing the sample maximum.

Distinct candidates within a world share the common shock and are dependent. Conditional on past volatility, their noise correlation before selection is `.36/.52=9/13`. Volatility depends on past state, so the sequence is not an iid constant-volatility experiment. Current innovations remain conditionally mean zero in the oracle filtration, which is the assumption the theorem needs. Independence across hypotheses is never invoked by the alpha-spending argument.

In ordinary mixed-effect cases, even pool indices have conditional mean equal to the specified positive effect, and odd indices have mean zero. In zero-effect cases, every candidate is null. A selected candidate's identity is frozen at birth; its mean remains the known pool effect under fresh subsequent draws. This supports the stored `null_at_birth` truth.

The weak-prefix case replaces every candidate's mean with `-.07,+.07,-.07,+.07,...`. Every post-birth prefix is nonpositive because this case uses a fixed family born before the first negative trial. It is not a strong-null world on its positive-mean trials. Configuration validation correctly forbids combining this generator with a nonzero effect or adaptive births, which could otherwise make a post-birth prefix start positive. Both fixed-mixture evidence methods have the qualified prefix-weak proof in the mathematical review; arbitrary adaptive bets would require a new result.

Gross utility is constructed as latent utility plus the current mean-cost difference and materiality. Subtracting the true coefficient and materiality therefore recovers the generated latent utility exactly. This intentionally puts zero-effect cases on the economic-materiality null boundary. The synthetic units are not basis points, Bitcoin log returns or factor alphas.

## 2. Actual versus oracle information and candidate births

The source order is causally correct for the registered synthetic game:

1. At the beginning of a trial, due hypotheses are born using accumulated past prescreen scores.
2. Selected identities are recorded, previously selected identities are excluded and test levels are already determined by birth rank.
3. Cost intervals and plugin estimates use only accumulated calibration data.
4. Turnovers and volatility are determined before current shocks are drawn.
5. Current common/individual shocks and outcomes are then generated.
6. Evidence, rejection state, prescreen scores and subsequent calibration observations are processed at the trial's maturity.

Prescreen scores are accumulated gross-minus-plugin-cost proxies, using data from previous matured trials. The selector never reads the latent effect array, null labels, current outcome or current calibration batch. `null_status` is computed by the evaluator from the selected effect, but does not feed back into candidate selection, stakes or deployment.

All candidate outcomes may be observed in the prescreen pool before a candidate is tested. This is allowed for hypothesis construction; evidence for the new hypothesis begins only when it becomes active. Log components start at zero, and every evidence/trial update is masked by `active`. Past prescreen outcomes are not copied into the new stream's evidence. Sampling current outcomes only after selection prevents choosing a candidate using the label that will be scored in its new test.

The first common shock is unobserved when first-trial turnover is set. Thereafter `previous_common` is used by the turnover rule. For an implementable adaptive policy, declare that this common market state becomes publicly observed at maturity. If the common shock is instead intended as a hidden decomposition of the observed score, the turnover rule would use oracle-past information and the manuscript must not call it an observable-policy rule. Volatility may be a hidden predictable environment variable; policy turnover needs the observable-state declaration.

This is adaptive selection from a finite pool with causal turnover adaptation. It is not a simulator of arbitrary program synthesis or an LLM researcher generating new trading code. Its conclusions should be scoped accordingly.

## 3. Delayed labels and maturity scheduling

With declared delay `d`, issue times are `0,d+1,2(d+1),...`, and maturity is `issue+d+1`. Only trials maturing by the fixed calendar horizon are generated/scored. There is no outstanding previous label when the next trial starts, and no intermediate feedback is modeled. Thus the schedule is the non-overlapping matured-trial case reviewed mathematically, not a result for overlapping financial horizons.

A zero declared extra delay still means an outcome matures one calendar step after issue. With delay four, labels mature every five steps. A 61-step smoke horizon correctly yields 12 matured trials. Births due during an outstanding trial are deferred until the next issue boundary, where selection occurs before the next draw.

Increasing delay reduces the number of matured utility observations at a fixed calendar horizon. Because new calibration is added per completed trial, it also reduces calibration accrual. That is the registered design; a result must not be attributed exclusively to label latency while ignoring reduced calibration information.

The simulation loop generates the trial outcome and then jumps conceptually to its maturity. It has no separate actor running within that interval, no intervening public price array and no policy callback that can inspect that current draw. This is sufficient for the declared game. It does not prove that hiding a score field would hide the same label in a financial market where public prices reveal it earlier.

## 4. Cost calibration and error accounting

Before time zero, each world receives a binomial aggregate representing `n_initial` bounded Bernoulli calibration observations in `[0,cap]` with mean `theta`. Later binomial batches are collected after a trial matures and become available for the next issue. A separate seeded calibration generator makes these independent of market innovations; this is stronger than the theorem's requirements but is a valid specified model.

The vectorized interval agrees with the independently tested scalar interval. The radius uses two-sided Hoeffding with `delta_n=6*delta/(pi^2*n^2)`. One interval is shared by all hypotheses in a world, and its failure budget is charged once. Utility tests split `alpha_family-delta` uniformly in fixed families or by `1/(j(j+1))` at adaptive births. Birth indices are allocated once in the runner's loop.

The coverage indicator checks the intervals actually used at issue times against the current true coefficient. It does not reconstruct all intermediate calibration prefixes before the aggregated initial sample. This is enough for the event inclusion needed by the implemented tests; the theoretical confidence sequence also covers the unused sample sizes under its stated law. Describe the recorded metric as any failure of an **issued/used cost envelope**, rather than an independently audited sample-path coverage curve for every initial calibration observation.

The cost-shift case deliberately changes the calibration mean halfway through the calendar horizon and is flagged as a stationarity/model violation. Its unknown-cost methods have no asserted nominal guarantee in the output. The latent known-cost oracle continues to have a valid conditional-noise law, so the generic no-guarantee label on all methods in that case is conservative rather than an inflation of claims.

Calibration is for a common **conditional-mean coefficient**. The runner does not generate separate realized execution-cost shocks for each deployed portfolio. Its net paper utility subtracts that model coefficient; it is not evidence of measured fill-cost coverage. Candles alone cannot justify the same assumption in the Bitcoin application.

## 5. Evidence constants, baselines and event inclusion

The vectorized component updates match the reviewed primitives. Linear components accumulate `log(1+lambda*Z)`, and normalized Hoeffding components accumulate `lambda*Z-lambda^2/2`. Components are fixed across time, with the registered equal-weight grid. Mixture calculation uses log-sum-exp of component wealth, not the geometric mean of components.

The latent bound is one and observed proxies are projected to `[-1,1]`. On interval coverage, projection preserves the lower-proxy relation. Joint and separate envelopes use the same component grid and test level, so pointwise cost geometry yields pathwise mixture and discovery nesting. The final runner additionally asserts that separate-envelope discoveries are nested in joint discoveries.

Latent linear and latent Hoeffding crossing events are tracked separately. At every maturity, an observed valid-proxy crossing must be accompanied by either a matching latent crossing or a coverage failure already recorded in that world. The check is run over all candidates, a stronger pathwise diagnostic than checking true nulls alone. It uses floating-point tolerances; it is not an exact-arithmetic replacement for the mathematical proof.

The oracle linear method receives the same utility-test allocation as the unknown-cost procedures, including the reserved cost-error amount it does not itself need. This is a deliberately matched-budget oracle comparison, not the most powerful possible known-cost test at full family alpha.

The fixed-horizon Hoeffding baseline uses boundary `sqrt(2*n*log(1/a_j))` only at the last matured calendar opportunity. With range length two, this is the correct fixed-time constant. Post-birth sample counts are determined by the registered schedule. The naive comparator repeatedly checks that same fixed-time boundary, so it has no stated anytime guarantee. A simulation need not show inflation in every finite case for that lack of guarantee to matter.

Plugin, symmetric-upper and naive-peek methods are visibly labeled unguaranteed. Deliberate assumption-violation scenarios are also visibly separated from controlled claims. No invalid comparator was found feeding a valid method's policy or truth label.

## 6. World-level metrics, censoring and activation

False rejection is computed as any rejected true null within a world. Alternative power is any rejected alternative in an eligible world; first-stream power is reported only when that stream is alternative in all worlds. Wilson intervals count independent worlds, not dependent hypotheses or repeated time points. The paired joint-only indicator also has a world-level Wilson interval.

Restricted first-alternative detection time uses calendar time from the study origin, with nondetections assigned the horizon. The conditional median includes only detected worlds and is explicitly labeled conditional. The two summaries answer different questions. Nondetections are not silently omitted from the restricted mean, and an all-censored sample no longer receives a spurious zero-width normal interval.

The paper-allocation rule is causal: before processing current evidence, it rewards only candidates deployed on earlier trials. A current crossing activates a candidate for later trials. Simultaneous crossings choose the lowest hypothesis index, and that candidate remains selected. This rule is explicit and does not choose a winner using the current reward after it is earned.

Materiality-adjusted utility accumulates latent `D`; reported mean-cost net utility accumulates `D+m`. This is an additive synthetic comparison. It does not simulate portfolio wealth, financing, compounding, capacity or actual execution. The fixed-horizon test crosses only at the final opportunity, so it has no subsequent paper-allocation reward within the studied horizon; that is a consequence of this deployment metric, not a defect in its statistical evidence.

Normal utility/time intervals are approximate world-level Monte Carlo summaries. A null interval after a degenerate sample is an honest limitation. The manuscript must retain that limitation and should not interpret zero observed allocations as proof that future discovery utility is exactly zero.

## 7. Reproducibility, configuration and freeze controls

Case seeds are derived deterministically from the registered base seed and case ID using SHA-256; calibration has a separately derived seed. Case order and selecting a single case do not change its seed. Identical dimensions/specifications reproduce result arrays and statistical summaries exactly under the reviewed runtime. Changing the number of worlds or horizon is not designed to preserve a nested prefix of the same world paths; smoke and substantive samples should not be treated as paired replications.

Runtime, wall-clock timestamps, run UUIDs and compressed-artifact bytes may differ across executions. Reproducibility of numerical results is distinct from byte-identical whole-run directories. Case outputs include world-level truth, rejection and crossing arrays, and the manifest hashes result JSON and NPZ files.

Configuration validation now rejects unknown top-level/case keys, unsafe names, invalid numeric settings, boolean counts, invalid turnover ratios/effects, unlabeled cost shifts and incompatible weak-prefix/adaptive-birth combinations. `run_study` validates the registered specification before use. Direct calls to the low-level simulation helper remain a responsibility of its caller; they are not a route to a validated substantive study merely because the function returns a dictionary.

Substantive `run_study` calls now require a freeze. The freeze pins source/test/dependency fingerprints, registered specification, protocol, named review documents and Python/NumPy versions. Checks reject changed source, protocol/review content, specification, runtime or an internally inconsistent seal. A new freeze cannot overwrite its prior output path. The ledger retains parent and per-case started/completed/failed attempts, and partial outputs are preserved.

This is local provenance and accidental-change control, not an externally witnessed registration or an adversarial security boundary. File existence and self-computed hashes do not prove scientific correctness, unseen data or prior human ignorance. The implementation correctly says that the simulation freeze does not freeze or authorize a market backtest.

## Verification performed

After rereading the final corrections, the following local command passed:

```powershell
.\.venv\Scripts\python.exe -m pytest tests/test_publication.py tests/test_cost_evidence.py --basetemp=runs/pytest-agent-publication-final -q
```

Result: **42 passed in 2.82 seconds**. This includes source/spec/protocol/runtime freeze mismatches, failed-attempt retention, zero-event uncertainty, calibration equivalence, birth freshness, delay boundaries, exact-repeat seeds and the new counterexamples.

An independent final-source smoke check ran **all 24 registered cases at 16 worlds and 61 calendar steps**, checking array dimensions, nonzero-upper paired intervals and pathwise crossing inclusion. Every case completed; every inclusion check passed. No case power/FWER estimate from these smoke runs is presented as research evidence.

A separate controlled accounting check used eight worlds and 20 calendar steps, forced positive market draws and arranged an oracle crossing at step one. It verified that paper utility excluded the triggering label, included exactly the following 19 labels, added materiality for those 19 labels only, and awarded no post-horizon utility to the fixed-horizon method. This intentionally controlled unit check is **not** a valid-null simulation and supplies no error-rate evidence.

## Conditions before substantive interpretation

- Declare the previous common shock observable at maturity for the turnover policy, and retain the actual/oracle distinction everywhere else.
- Retain the fixed-mixture prefix-weak proof and avoid describing the positive-mean trials in the weak-prefix case as satisfying the strong null.
- Freeze final source/tests/protocol/review hashes after any additional tests or documentation edits. Run the complete registered case matrix without choosing cases or altering settings in response to results.
- Preserve unguaranteed labels, used-envelope coverage scope, calendar-origin censoring and unavailable degenerate-sample intervals in generated tables and figures.
- Treat this as a controlled synthetic mechanism study. All 24 cases passing smoke checks establishes neither practical power nor a substantive original finance finding. Those require the frozen full runs, uncertainty reporting and the separate market and literature work.

This review supports proceeding to the registered substantive synthetic study after those declarations and the final freeze. It does not certify a financial strategy, live cost model, profitability, novelty or publication readiness.
