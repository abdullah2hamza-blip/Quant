# Independent mathematical design review 01

Review date: October 21, 2026. Scope: mathematical direction and nearest primary literature; implementation has not been reviewed against the results below. This document was written independently of the main implementation. No source or existing result artifact was changed.

## Assessment

A useful study is possible, but the elementary safety composition and the paired-cost support-function identity should not be presented as new statistical methods. The clearest potential contribution is a reproducible study of the inferential and power consequences of misrepresenting paired cost uncertainty, accompanied by counterexamples and an honest Bitcoin robustness analysis.

The proposed additive error budget is correct under an explicit **oracle-filtration conditional null**. It is generally wrong to prove it by conditioning on a high-probability cost-coverage event. It can also be wrong if the null conditions only on observable histories while persistent latent costs induce dependence in latent utility. This distinction is essential, not a technical footnote.

The proposed common-cost refinement is correct under a common linear conditional-mean cost model. It does not establish that two actual execution costs share the same realized slippage coefficient, and it does not make an OHLC backtest a sequential test with calibrated cost uncertainty.

## 1. A precise setup with delayed labels

Let `A_s` be the actual information available by wall-clock time `s`: public market information, matured feedback, calibration observations, previous rejections and research decisions. Let `F_s` be an oracle enlargement that also contains all **past matured latent paired utilities**. It must not reveal a future utility before the trial that generates it. Actual decisions are measurable with respect to the actual information set, hence also the oracle information set.

For hypothesis `j`, let its birth time be `b_j`. At birth, freeze the candidate algorithm or causal updating rule, reference, utility, materiality threshold, outcome horizon and evidence method. An algorithm may continue adapting according to that rule; choosing a new rule after seeing its evaluation outcomes is a new hypothesis. Testing a newly born hypothesis uses only its subsequent trial outcomes.

For its `n`th trial, let `s_{j,n}` be the decision/start time and `r_{j,n}` its maturity time. Require

\[
b_j\le s_{j,1}<r_{j,1}\le s_{j,2}<r_{j,2}\le\cdots .
\]

This is the practical non-overlapping, no-outstanding-label case. A trial's policy and evidence stake are fixed before that trial's outcome is revealed. A label is added exactly once, at maturity. The simulation must not expose pre-generated outcome arrays, the current label or latent cost parameter to a policy before its permitted decision time.

For concise notation, set `H_{j,n}=F_{r_{j,n}}` and `B_{j,n}=F_{s_{j,n}}`. Then

\[
H_{j,n-1}\subseteq B_{j,n}\subseteq H_{j,n}.
\]

The additional pretrial information between maturities is allowed. The conditional-null assumption is imposed at `B_{j,n}`, which includes everything actually known at the decision, and oracle past utilities. The proof uses the tower property; it does not pretend that a stake chosen at the new trial's start was necessarily known immediately after the previous trial matured.

Public prices can reveal part or all of a nominally delayed score. Merely suppressing a score column does not remove that information from `A_s`. Either model this information honestly and freeze the trial's stake before its outcome, or use a simulator in which the relevant feedback really is delayed. General overlapping-label claims require a separate lagged-filtration construction; they do not follow from the theorem below.

## 2. Latent paired utility and the cost proxy

In a realized-cost formulation, define

\[
D_{j,n}=G_{j,n}-C^A_{j,n}+C^R_{j,n}-m_{j,n},
\]

where `G` is the gross adaptive-minus-reference utility difference, both costs are in the same utility units and `m` is a prespecified materiality deduction. Assume `D` is `H_{j,n}`-measurable and lies in `[-B,B]` for a known, prespecified finite `B>0` under every generating law covered by the claim.

An implementable lower proxy is

\[
L_{j,n}=G_{j,n}-U^A_{j,n}+\ell^R_{j,n}-m_{j,n},
\]

with an upper bound on the adaptive cost and a **lower** bound on the reference cost. Suppose there is one simultaneous event

\[
\mathcal G=\{L_{j,n}\le D_{j,n}\text{ for every born }j\text{ and evaluated }n\},
\qquad P(\mathcal G^c)\le\delta.
\]

Coverage is for the actual adaptive research/calibration procedure, not just for a prespecified row or a fixed sample size. It may instead be obtained from individual conditional-on-birth coverage guarantees with failure budgets whose sum is at most `delta`. No independence between coverage, strategy outcomes or hypotheses is required by the composition proof.

Use `Z=clip(L,-B,B)`. On `G`, monotonicity and the latent bound imply `Z<=D`. This flooring avoids negative linear e-factors when a conservative proxy falls below `-B`. It does not justify imposing a bound on an actually unbounded latent utility. If the intended latent utility is itself a clipped return difference, the null and economic interpretation are about that clipped utility; report untransformed economic outcomes separately.

The realized-cost formulation is different from a **conditional-mean cost model**; Section 5 gives that alternative precisely.

## 3. Domination plus a coverage-failure budget

### Proposition: strong conditional null, predictable births and FWER

For every true null hypothesis `j`, assume

\[
E[D_{j,n}\mid B_{j,n}]\le0\quad\text{a.s. for every }n.
\]

Choose an actual predictable stake `lambda_{j,n}` in `[0,1]`, measurable at `B_{j,n}`. It may be a causal function of past observed proxies and research decisions. Define the observed wealth and a latent comparison wealth using the **same realized stakes**:

\[
W_{j,n}=\prod_{i=1}^n\left(1+\lambda_{j,i}Z_{j,i}/B\right),
\qquad
M_{j,n}=\prod_{i=1}^n\left(1+\lambda_{j,i}D_{j,i}/B\right).
\]

At birth, allocate a nonnegative level `a_j` measurable with respect to birth information. Require the pathwise budget `sum_j a_j <= alpha_test`. Test `j` by crossing `W_{j,n} >= 1/a_j`; a zero level means no rejection. The budget counts all born hypotheses, including abandoned or failed attempts, and is not refunded merely because a test has not rejected.

For strong FWER, true-null indices may be deterministic under each generating law. If null status itself is described as depending on the realized birth history, require that status to be measurable at birth and that the displayed conditional-null assumption hold on those null birth histories. Arbitrarily declaring a hypothesis null after inspecting its later outcomes is outside this formulation.

Then

\[
P(\text{at least one false rejection})\le\alpha_{\rm test}+\delta.
\]

This is FWER, not FDR. To target total level `alpha_total`, reserve an explicit coverage budget and use `alpha_test + delta <= alpha_total`.

### Proof

All factors in `M` are nonnegative. Because `M_{j,n-1}` is measurable at `B_{j,n}` and the stake is chosen there,

\[
E[M_{j,n}\mid B_{j,n}]
=M_{j,n-1}\left(1+\lambda_{j,n}E[D_{j,n}\mid B_{j,n}]/B\right)
\le M_{j,n-1}.
\]

Taking conditional expectations again at `H_{j,n-1}` proves that `M_j` is a nonnegative test supermartingale in the maturity-indexed oracle filtration, starting from one. Conditional Ville at birth gives a latent crossing probability at most `a_j`. Conditional-on-birth validity is needed if levels or candidate definitions depend on birth history; marginal fixed-hypothesis validity is not an automatic substitute.

On `G`, each observed factor is at most its latent factor, since stakes are nonnegative. Thus `W_{j,n}<=M_{j,n}` for all `j,n` simultaneously, even though the common stakes adapt to past observed proxies. Any observed false crossing belongs either to `G^c` or to a true-null latent crossing. A union bound, conditional Ville and the budget condition yield

\[
\begin{aligned}
P(\exists\text{ false observed crossing})
&\le P(\mathcal G^c)
+\sum_j E[\mathbf1\{j\text{ true null}\}a_j]\\
&\le\delta+\alpha_{\rm test}.
\end{aligned}
\]

For a countable family, take limits of finite unions. Dependence across candidates and the reuse of the same future market observation by several already-born candidates do not invalidate this union bound, provided each candidate's conditional-null assumption holds in the specified full information set. Research reuse of already inspected outcomes to select a new hypothesis and then score it on those same outcomes does violate the birth requirement.

The proof does **not** condition the supermartingale on `G`. Nor does it claim `W` is an e-process when `delta>0`: its behavior on the failure event can destroy e-value expectations. What is established is the stated crossing-probability bound. Mixtures of latent test supermartingales, with nonnegative weights fixed at birth summing to one, support the same argument.

### Why conditioning on coverage is invalid

Let `0<delta<1/2`, and let a one-step latent utility be `a=delta/(1-delta)` with probability `1-delta` and `-1` with probability `delta`. Its mean is zero and it is bounded by one. Let `L=a` and define the coverage event `G={D=a}`. On `G`, the proxy is exact. Nevertheless,

\[
E[1+\lambda D\mid\mathcal G]=1+\lambda a>1\quad(\lambda>0).
\]

Coverage selects positive outcomes. Therefore a supermartingale before conditioning need not remain a supermartingale under the law conditional on coverage. The unconditional domination proof above avoids this error.

## 4. A counterexample if the null uses only observable histories

The oracle qualification cannot simply be omitted. Take `delta=.05`, draw a hidden variable `Y` once, and let

\[
Y=1/19\quad\text{with probability }.95,
\qquad Y=-1\quad\text{with probability }.05.
\]

Set `D_n=Y` and `L_n=1/19` for every `n`. Let the observable history contain the constant proxies but never reveal `Y`. Then

\[
E[D_n\mid A_{n-1}]=0\quad\text{for all }n,
\qquad P(\forall n:L_n\le D_n)=.95.
\]

With any constant positive stake, observed wealth is `(1+lambda/19)^n`, so it crosses every finite threshold with probability one. This exceeds `alpha_test+.05` for ordinary levels. In the oracle history, past `D` reveals `Y`, and the conditional-null assumption fails on the `.95` positive branch. Thus the example does not contradict the proposition; it refutes the weaker observable-history theorem.

It also has a cost interpretation: gross difference `a=1/19`, reference cost zero, adaptive cost zero with probability `.95` and `1+a` with probability `.05`, with the hidden adaptive cost shared persistently over time. A zero upper-cost estimate covers all times with probability `.95`, yet the observed proxy always appears positive.

A fixed unknown model parameter is different from such an unconditioned persistent random effect. A guarantee stated under each law `P_theta` can treat `theta` as fixed. If the simulation draws `theta` once per world, it must verify the conditional null under each parameter law or condition on that draw in the oracle setup; mean neutrality only after mixing worlds is insufficient.

## 5. Common-cost geometry and what it assumes

Suppose `qA,qR>=0` are predictable turnovers in the same return/utility normalization, and `theta` is an unknown common cost coefficient. Define `d=qA-qR` and

\[
D=G-d\theta-m,\qquad \theta\in[\ell,u].
\]

The robust lower proxy using the shared parameter is

\[
\begin{aligned}
L_{\rm joint}
&=G-m-\sup_{\theta\in[\ell,u]}d\theta\\
&=G-m-d(\ell+u)/2-|d|(u-\ell)/2.
\end{aligned}
\]

Separately bounding the two costs gives

\[
L_{\rm rect}=G-m-q_Au+q_R\ell.
\]

Consequently,

\[
L_{\rm joint}-L_{\rm rect}
=\min(q_A,q_R)(u-\ell)\ge0.
\]

If `qA=qR`, uncertainty in the common coefficient cancels exactly in the paired contrast. This says nothing about costs unique to a portfolio: separate impact, fill, direction, fee tier or latency terms do not cancel without corresponding identifying restrictions. A vector cost model yields the standard support function `sup_{theta in C} d^T theta`; replacing a joint set by a Cartesian product can only weaken the resulting lower bound. This is elementary robust optimization.

There are two distinct interpretations:

1. **Realized coefficient:** `C^A=qA*theta`, `C^R=qR*theta` as a statement about the actual costs in each block. The interval must cover those realized coefficients simultaneously. Merely estimating their average does not establish this.
2. **Conditional-mean coefficient:** assume `E[C^A | B]=qA*theta` and `E[C^R | B]=qR*theta`, with a fixed common `theta` under each model law, or a prespecified predictable parameter process. Then `D=G-d*theta-m` has the same conditional mean as realized net utility. A confidence sequence for that **mean parameter** can justify a simultaneous parameter-coverage event. It is not an interval for each realized slippage. Boundedness is required for this `D` or for whatever alternative evidence construction is used, and all expectations must exist.

For the conditional-mean version, a usable calibration model is bounded calibration observations with conditional mean `theta`, sampled without outcome-based selection under the actual calibration schedule. Use only the parameter set available when a trial is started, and include calibration information in the null's information set. A single simultaneous confidence sequence for one global `theta` need not pay a fresh failure budget for every portfolio; separate venues, directions or parameter models need their own jointly valid coverage allocation. Fixed-time pointwise intervals do not provide this coverage.

The Bitcoin backtest's exact self-financing accounting is not automatically equivalent to `gross difference - turnover*theta`. Fees change cash, positions, future turnover and potentially adaptive choices; log-NAV cost effects are nonlinear. A common-coefficient synthetic model can isolate the geometry cleanly, while market experiments retain exact accounting and disclose the modeling gap. Do not reinterpret a stress grid as a calibrated confidence sequence.

Even if `theta` is constant over all trials, minimizing the contrast separately in every trial may allow different adverse endpoints in different trials. Thus the displayed construction does not exploit all temporal coherence of a fixed parameter. A whole-path nuisance-robust construction could be considered separately, but is beyond this initial implementation and should not be implied by the paired-width identity.

### Increment domination versus wealth domination

Pointwise `L_joint>=L_rect` implies pathwise wealth domination when both methods use the same stakes, the same utility bound, or the same fixed-lambda mixture and weights. It does **not** imply domination if each method independently adapts its betting rule.

For example, take `B=1`, streams `x=(.1,.2)` and `y=(0,.19)`, and the same rule `lambda_1=1`, `lambda_2=1{first observation<=.05}`. Although `x>=y` coordinatewise, the resulting wealth is `1.1` for `x` and `1.19` for `y`. The rule reacts differently to the first observations. This does not affect the proxy-versus-latent proof in Section 3: that proof deliberately uses the identical realized observed-history stakes in both wealth processes.

## 6. Two further false-discovery counterexamples

### Pointwise coverage can fail under indefinite monitoring

Let true latent utility be `D_n=0`. Independently at each trial let `L_n=1` with probability `delta>0`, and `L_n=0` otherwise. Each pointwise bound has even conditional coverage `P(L_n<=D_n | past)=1-delta`. With stake one, however, wealth is `2` to the power of the number of failures and eventually crosses every finite threshold almost surely.

One cost representation is gross difference one, adaptive cost one and reference cost zero. The adaptive upper-cost estimate is zero on a failure and one otherwise. This has pointwise coverage but no nontrivial simultaneous infinite-horizon coverage. Valid repairs include a genuine confidence sequence for the relevant parameter/model, or per-trial failure budgets with a justified summable total. Neither repair licenses an unjustified cost model.

### Applying upper costs to both portfolios can be anti-conservative

Consider a common true cost coefficient `theta=.01`, turnovers `qA=1`, `qR=2`, gross difference `G=-.01`, and materiality zero. Then true paired net utility is

\[
D=-.01-.01+.02=0.
\]

Use a perfectly valid upper coefficient `u=.02` for **both** portfolios. Their separately pessimistic net performances give the contrast

\[
L_{\rm wrong}=-.01-.02+.04=.01>0.
\]

Repeating this deterministic null example makes any positive-stake product reject eventually. Both costs were individually overestimated, but the more active reference was penalized more. Therefore pessimism about each absolute portfolio performance does not imply pessimism about their difference. In general,

\[
L_{\rm wrong}-D=(U^R-C^R)-(U^A-C^A),
\]

which has no fixed sign. The valid shared-parameter lower contrast selects the endpoint according to `sign(qA-qR)`; the valid rectangular contrast uses upper adaptive and lower reference cost.

## 7. Strong versus prefix-weak nulls

The linear betting product tests the strong null `mu_n=E[D_n | B_n]<=0` in every trial. Rejecting it establishes evidence against uniform conditional non-improvement. It does not, by itself, establish positive average utility over the observed period, positive expected terminal wealth or future deployable profit.

A more economically interpretable comparison is the prefix-weak null

\[
\sum_{i=1}^n\mu_i\le0\quad\text{a.s. for every prefix }n.
\]

This is still a process hypothesis. Its rejection says some tested prefix has positive cumulative conditional expected utility; an anytime confidence sequence for the running average states the time-specific conclusion more clearly. It does not establish that every later prefix will remain positive or that the market is stationary.

For a simple existing-method baseline, let `D_i in [-B,B]`, fix `lambda>=0` at birth and use conditional Hoeffding's lemma:

\[
N_n(\lambda)=\exp\left\{\lambda\sum_{i=1}^n(D_i-\mu_i)-\tfrac12 n\lambda^2B^2\right\}
\]

is a test supermartingale. Under the prefix-weak null,

\[
E_n(\lambda)=\exp\left\{\lambda\sum_{i=1}^nD_i-\tfrac12 n\lambda^2B^2\right\}\le N_n(\lambda).
\]

On the coverage event, replacing `D_i` by `Z_i` can only reduce `E_n`. A mixture over fixed nonnegative lambdas, with weights fixed at birth, therefore has the same `alpha_test+delta` FWER composition. Use log-sum-exp numerics. The factor `B^2/2` follows from range length `2B`; accidentally treating the range length as `B` is anti-conservative.

Arbitrary adaptive lambda weights cannot be inserted into the prefix-weak argument: a nonpositive unweighted prefix sum of means need not imply a nonpositive adaptively weighted sum. Likewise a mean-zero dependence example can violate the oracle strong null while still appearing neutral after averaging independent worlds.

This Hoeffding construction is transparent but may be underpowered. Choe and Ramdas provide variance-adaptive paired-score procedures, including the weak-null interpretation, as prior art rather than a proposed novelty. Economic materiality must be specified in the exact utility units before testing. Annualizing a utility estimate is not a proof of an annual return guarantee.

## 8. Nearest primary sources and novelty boundaries

The following sources were consulted through primary publisher, author or arXiv material. Technical relevance is specific; none should be cited as proving actual Bitcoin execution-cost coverage.

- **Choe and Ramdas, Comparing Sequential Forecasters**, *Operations Research* 72(4):1368–1387, 2024 issue, published online October 2023, [DOI 10.1287/opre.2021.0792](https://doi.org/10.1287/opre.2021.0792); [full text](https://arxiv.org/html/2110.00115v4). Sections 4.2–4.4 explicitly distinguish observable/oracle information and strong/weak nulls; Appendices E–F address lagged forecasts, predictable subsequences and bounds. This substantially subsumes a broad claim of new sequential comparison of adaptive bounded paired performance. Its established weak-null methods are important comparators.
- **Choe and Ramdas, Combining Evidence Across Filtrations**, [arXiv:2402.09698](https://arxiv.org/abs/2402.09698), [inspected full text v3](https://arxiv.org/html/2402.09698v3). The lifting results and Section 5.2 show why evidence valid in coarser lagged filtrations is not automatically valid for full-information stopping and provide existing adjustments. Restricting the first study to non-overlapping matured trials avoids claiming this existing extension as new.
- **Waudby-Smith and Ramdas, Estimating means of bounded random variables by betting**, [DOI 10.1093/jrsssb/qkad009](https://doi.org/10.1093/jrsssb/qkad009); [full text](https://arxiv.org/html/2010.09686v7). Predictable bounded-mean betting and confidence sequences are established. The linear product and adaptive stake choice here are direct instances of that framework.
- **Howard, Ramdas, McAuliffe and Sekhon (2021), Time-uniform, nonparametric, nonasymptotic confidence sequences**, *Annals of Statistics* 49(2):1055–1080, [DOI 10.1214/20-AOS1991](https://doi.org/10.1214/20-AOS1991); [primary version](https://arxiv.org/abs/1810.08240). Provides the established time-uniform concentration and mixture-supermartingale foundations for Hoeffding and stronger confidence-sequence baselines.
- **Ramdas, Gruenwald, Vovk and Shafer (2023), Game-Theoretic Statistics and Safe Anytime-Valid Inference**, *Statistical Science* 38(4):576–601, [DOI 10.1214/23-STS894](https://doi.org/10.1214/23-STS894); [author-hosted full text](https://safestatistics.com/wp-content/uploads/2023/10/RamdasSAVIStatScience23.pdf). Reviews the established distinction between supermartingales and processes dominated by appropriate supermartingales. Ville plus pathwise domination is not a new testing principle.
- **Tian and Ramdas (2021), Online control of the familywise error rate**, *Statistical Methods in Medical Research* 30(4):976–993, [DOI 10.1177/0962280220983381](https://doi.org/10.1177/0962280220983381); [primary manuscript](https://par.nsf.gov/servlets/purl/10251926). Alpha spending for an indefinitely growing family is established; their more powerful procedures use additional dependence/validity conditions. The simple conditional-on-birth Bonferroni argument here needs no independence across hypotheses.
- **Ben-Tal and Nemirovski (1998), Robust Convex Optimization**, *Mathematics of Operations Research* 23(4):769–805, [DOI 10.1287/moor.23.4.769](https://doi.org/10.1287/moor.23.4.769); [author PDF](https://www2.isye.gatech.edu/~nemirovs/MOR_RCO_1998.pdf). Worst-case linear contrasts over joint uncertainty sets are classical robust counterparts. The common-theta interval identity is an elementary special case, not an original optimization result.
- **Berger and Boos (1994), P Values Maximized Over a Confidence Set for the Nuisance Parameter**, *JASA* 89(427):1012–1016, [DOI 10.1080/01621459.1994.10476836](https://doi.org/10.1080/01621459.1994.10476836). Restricting a nuisance search to a confidence set and paying its failure probability is an established idea. Only publisher abstract/metadata were accessible in this review, so this is a conceptual predecessor, not an assertion that its fixed-sample theorem directly proves the delayed sequential result.
- **Clerico (2025), On the optimality of coin-betting for mean estimation**, *International Journal of Approximate Reasoning* 187:109550, [DOI 10.1016/j.ijar.2025.109550](https://doi.org/10.1016/j.ijar.2025.109550); [full text](https://arxiv.org/html/2412.02640v3). Characterizes coin-betting optimal classes for bounded-mean testing, including fixed-conditional-mean extensions. It further weakens a broad novelty claim for choosing affine one-step factors; its equality-null optimality statement should not be misquoted as a complete result for every cost model considered here.
- **Csillag, Struchiner and Goedert (2025), Prediction-Powered E-Values**, ICML, PMLR 267:11493–11514, [proceedings](https://proceedings.mlr.press/v267/csillag25a.html). Provides a different established way of using proxy predictions with labeled corrections. It is a relevant comparator if genuine realized fill labels can be sampled; it does not justify replacing unobserved costs by an uncalibrated proxy.
- **Wang and Ramdas (2023), Huber-robust confidence sequences**, AISTATS, PMLR 206:9662–9679, [proceedings](https://proceedings.mlr.press/v206/wang23p.html). Treats a specified distribution-corruption model, unlike the one-global-envelope-failure model here. It is adjacent robust sequential inference, not a source for an arbitrary claim of cost robustness.

No inspected standalone theorem was needed to derive the exact Section 3 statement: conditional bounded betting, pathwise event inclusion, Ville and a union bound prove it immediately. Existing general domination and online error-accounting results already contain its statistical substance. Failure to locate identical financial notation is not evidence of methodological novelty. Any strong novelty claim still needs deeper checking of the direct financial e-backtesting and anytime factor-alpha papers already registered in the repository.

## 9. Required experiment and implementation checks

The following are focused checks for the promised design, not completed implementation verification:

1. Separate strong-null linear mixtures and prefix-weak Hoeffding mixtures in configuration, artifacts and result interpretation. Include known-truth worlds satisfying only the weak null, as well as deliberate violations.
2. Verify the common-theta algebra for positive, zero and negative turnover differences, equal turnover, zero uncertainty width and asymmetric portfolios. Compare joint and rectangular methods with the same fixed lambdas/mixture weights before making power claims.
3. Include the persistent hidden-cost counterexample, pointwise-only coverage and upper-cost-for-both examples above. A simulator that treats their rejection as a valid discovery has encoded the wrong null or coverage assumption.
4. Check exact event accounting: envelope failure, latent crossing and observed false crossing separately; verify pathwise observed crossing implies failure or a latent crossing. Report actual simultaneous coverage, not only pointwise coverage.
5. Use independent worlds as the Monte Carlo units. Correlated hypotheses and labels within one world are not independent binomial observations. Report world-level FWER/power uncertainty and detection delay with non-detections explicitly censored.
6. Test birth histories and budgets, changed strategies, abandonment, fixed prior data and research reuse. A history-dependent candidate may use prior research data to define its rule, but its new test cannot reuse those outcomes as fresh evidence.
7. Test that no candidate or stake function receives current or future labels, including information implicitly revealed through market arrays. Check mature-once FIFO updates, delay boundaries and the no-outstanding-label condition per candidate.
8. For calibrated theta intervals, verify confidence-sequence coverage under the stated bounded conditional-mean sampling law and separate it from misspecification. Dynamic or state-dependent cost coefficients are violations of a constant-theta model unless explicitly modeled.
9. Keep the market evidence descriptive/retrospective unless the latent conditional-null, utility bound and cost-coverage assumptions are separately defended. A bootstrap interval, cost grid or selected historical price history is not such a defense.

## Unresolved before a publication-readiness claim

The primary unresolved scientific question is whether preserving paired cost geometry produces a practically meaningful power improvement under a credible mean-cost model and whether this insight is new enough as an empirical finance contribution. The safety lemma and width identity alone are insufficient.

Actual historical fill-cost coverage remains unidentified from candles alone. The economic target also needs a final choice between strong conditional non-improvement, the prefix-weak conditional-average null and retrospective average net log growth. These targets cannot be interchanged in conclusions. The registered synthetic design can establish validity under its assumptions and expose failures; the market study can establish sensitivity and observed performance, but it cannot identify true false-discovery rates from one Bitcoin history.

This review endorses implementing and testing the carefully qualified composition as established methodology. It does not certify the future implementation, empirical results, novelty or publication readiness.

## Addendum: fixed linear mixtures also support the prefix-weak null

Added during the subsequent implementation review on October 21, 2026. This sharpens the earlier sufficient strong-null result; it does not invalidate it. Section 3 allowed arbitrary predictable stakes. The following result requires each mixture component's stake to be **fixed at birth**, and therefore does not extend that result's arbitrary adaptive-stake guarantee to the prefix-weak null.

Fix a hypothesis, retain the two-stage oracle filtration from Section 1, and put `X_n=D_n/B` and `nu_n=E[X_n | B_n]`. Suppose `X_n in [-1,1]` and

\[
\sum_{i=1}^n\nu_i\le0\quad\text{a.s. for every }n.
\]

For a fixed birth-measurable `lambda in (0,1)`, define

\[
K_n(\lambda)=\prod_{i=1}^n(1+\lambda X_i),\qquad
A_n(\lambda)=\prod_{i=1}^n(1+\lambda\nu_i),\qquad
R_n(\lambda)=K_n(\lambda)/A_n(\lambda).
\]

The denominator is strictly positive because `nu_i in [-1,1]` and `lambda<1`. At each pretrial decision time,

\[
E\left[\frac{1+\lambda X_n}{1+\lambda\nu_n}\,\middle|\,B_n\right]=1.
\]

Using the tower property through the two-stage filtration makes `R_n` a positive maturity-indexed martingale starting at one, conditionally on birth. No observable estimate of `nu_n` is needed; the martingale is a null-law-specific object used only in the proof. Furthermore,

\[
\log A_n(\lambda)
=\sum_{i=1}^n\log(1+\lambda\nu_i)
\le\lambda\sum_{i=1}^n\nu_i\le0.
\]

Thus `K_n=A_n R_n<=R_n` at every prefix. The latent fixed-stake linear wealth is therefore an e-process for the prefix-weak null by domination, although it need not be a supermartingale for that larger null class. If nonnegative weights and fixed lambdas are chosen at birth, the corresponding mixture of `K` is dominated by the same mixture of `R`, which is a test martingale. Conditional Ville applies.

On a simultaneous cost-coverage event, `clip(L_i,-B,B)/B<=X_i`, and every fixed-stake linear factor is monotone. The observed proxy mixture is bounded by the latent `K` mixture and hence by the `R` mixture. The Section 3 argument then gives the same FWER bound `alpha_test+delta` for the prefix-weak null. It still does not make a high-probability-envelope proxy mixture an exact e-process on its failure event.

The strong conditional null is a subset of this prefix-weak null. Under the strong null, the direct supermartingale proof remains available and permits arbitrary predictable stakes. Under the prefix-weak null, refitting lambdas, mixture weights or the normalization bound across trials requires a new proof. In particular, `sum nu_i<=0` does not control `sum lambda_i*nu_i`. A constant utility bound is used here; changing its scale can act like changing the stake on the original economic utility.

The distinction can be checked exactly on nonstationary Bernoulli paths. An independent review calculation enumerated all 64 six-step paths with outcomes `D_i in {-2,+2}`, `B=2`, positive-outcome probabilities alternating `.25,.75`, and mixture grid `(.1,.3,.8)`. Conditional means alternate `-1,+1`, so every prefix satisfies the weak null while positive-mean trials violate the strong null. Linear wealth was below its ratio-martingale mixture at every prefix; the probability-weighted terminal martingale mean was `1.0000000000000002`. This finite calculation is a numerical check, not the proof.

### Primary-literature search and originality status

Targeted searches included combinations of “weak null,” “constant betting,” “product e-process,” “conditional means” and “prefix.” The closest inspected primary sources remain [Choe and Ramdas, Comparing Sequential Forecasters](https://arxiv.org/html/2110.00115v4), including its weak-null and product-versus-exponential discussions, and [Waudby-Smith and Ramdas, Estimating means of bounded random variables by betting](https://academic.oup.com/jrsssb/article/86/1/1/7043257), particularly its universal representation of test martingales. Neither inspected passage was located as an explicit statement of this exact constant-linear-stake prefix-weak proposition. This is a limitation of the search, not evidence of absence.

The ratio factor can itself be written

\[
\frac{1+\lambda X_n}{1+\lambda\nu_n}
=1+\frac{\lambda}{1+\lambda\nu_n}(X_n-\nu_n),
\]

which is standard predictable mean-centered betting. The proof is an elementary multiplicative-compensator argument plus `log(1+x)<=x`, followed by the established e-process domination principle. It should be presented as an elementary proposition used to characterize the implemented baseline, not as an original methodological contribution. It also does not weaken the oracle-filtration requirement or repair the hidden-cost counterexample in Section 4.
