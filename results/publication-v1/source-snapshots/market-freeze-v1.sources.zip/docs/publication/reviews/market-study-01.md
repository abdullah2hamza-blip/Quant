# Independent market application review 01

Reviewed on 2026-10-21/22, completed 2026-10-22 UTC, before evaluating or inspecting strategy P&L on the newly acquired real 2025-2026 observations. This review is independent of the implementation author within the same agent workflow; it is not external peer review. No source or protocol edits were made by the reviewer. Only synthetic fixtures were evaluated.

## Disposition and scope

No blocking causal, accounting, or statistical-reporting defect was found in the six registered market cases at the fingerprints below. The implementation is suitable for the separately frozen **retrospective descriptive application** specified in `market-protocol-v1.md`. This disposition does not validate market profitability, prospective generalization, actual execution costs, bootstrap coverage under arbitrary market regimes, or the bounded synthetic evidence model for financial returns.

The review covered `market_study.py`, `venues.py`, the independent Bitstamp reconciliation script, their tests, the market JSON specification and protocol, and the supporting engine, configuration conversion, data audit, bootstrap, ledger, and source-snapshot implementations. It did not run `evaluate_market_case` or `run_market` on real data, open real market result files, calculate new-period real strategy P&L, or inspect future portfolio returns. The reviewer did not independently download or reconcile the real vendor snapshots during this review: the assessment of reconciliation is code inspection plus mocked-data checks, with actual snapshot evidence to be pinned by the freeze.

## Findings resolved before the final fingerprint

1. The original specification parser accepted a one-day block for daily candles, although the bootstrap requires at least two observations per block. Such a specification could pass parsing and fail only after portfolio simulation. `load_market_spec` now rejects physical blocks shorter than two candles for every declared timeframe, and a new test covers the daily case. The registered 15/30/60-day grid was unaffected.
2. The protocol now states that the ensemble includes all three candidates, including the reference. This removes the ambiguous statement that the reference was the third constituent; 50/200 is the second listed EMA pair.
3. The gap policy now states the engine's actual behavior: the incumbent adaptive pair can resume trading after feature warm-up, whereas selecting another pair waits for a full new selector history. The implementation does not reset the incumbent or force it to stay uninvested until selection is eligible. This distinction was initially ambiguous in the prose and is now explicit.

No unresolved material implementation finding remains for the registered cases. The limitations below remain substantive limits on interpretation.

## Causal execution, selection, and inherited state

Features use completed close observations. A target at close index `i-1` can execute only at opening index `i`; the simulator does not use the execution candle's eventual high, low, close or volume to choose the target. The weight-band decision and exact post-fee target trade use the observed execution open. Filling a completed-candle signal at the next open is an explicit idealized fill assumption; no capacity, latency or executable quote claim follows from it.

Continuous shadow books are simulated with the same feature history and base costs as the fixed candidates. At a selection close `t`, the score is `(log NAV[t] - log NAV[t-L]) / L`, which uses the already completed returns `t-L+1,...,t`. The new selection affects the next opening trade. The first eligible selector close follows the warm-up plus the full trailing-return history. Prefix mutation tests confirm that changing later prices does not alter earlier features, selection decisions, or saved portfolio paths.

The market wrapper requires valid selector history at the close immediately before the declared score start. It checks the original prehistory boundary and exact requested score boundary and does not shift an ineligible start. It simulates the continuous history, then scores from the prior close rather than restarting either portfolio with fresh cash. Cash, coins and prior-close NAV are saved for each cost/strategy. Consequently an inherited position's first scored overnight/open move is correctly included, while its historical entry cost is not charged again. These are continuous-strategy returns, not a new investor's entry-at-window-start results.

Gaps cancel the crossing order and carry existing holdings. Features restart after a gap. The selected pair persists through the pause; it resumes after feature warm-up, while a new selection requires the full trailing history. No missing candle is filled or silently interpolated. A gap inside a scored return sequence suppresses regular-grid annualized mean, volatility, Sharpe and the bootstrap. Cumulative marked returns and elapsed-calendar-time CAGR remain descriptive accounting quantities; they are not lost-interval volatility estimates. Dataset acceptance requires positive retained volume, rather than making an opening trade depend on the completed execution bar's future volume.

## Self-financing costs, attribution, and controls

The buy and sell target equations account for the effect of fees on post-trade NAV. They charge the assumed rate on absolute traded notional, preserve nonnegative cash/coin holdings and implement complete exits exactly. The attribution wrapper reconstructs pre-trade open wealth from inherited holdings, post-trade open wealth from current holdings, and closing wealth from NAV. Its three log components telescope to the recorded return, and its fee residual verifies `pre-trade wealth - post-trade wealth = charged cost`. The identity handles differing adjacent closes/opens, inherited holdings and observation gaps. It is an accounting identity, not a causal decomposition of adaptive alpha.

The base-cost case is evaluated first. Its selection schedule is then frozen for every other cost scenario, including prehistory and inherited holdings. Each scenario re-executes the same declared target procedure, allowing fee-dependent wealth, position weights and band-triggered trades to evolve. This avoids presenting a linear ex-post turnover subtraction as the exact sensitivity of a self-financing strategy. The intermediate stressed selector calculation inside `run_suite` is overwritten by the supplied frozen choices and does not affect the resulting adaptive target path.

The nine reported books include the adaptive and fixed policies, both other fixed candidates, the target-weight ensemble, cash, buy-and-hold, volatility targeting and slow reference resizing. The latter always permits entry/exit transitions and delays only nonzero-position resizing. Buy-and-hold and volatility targeting share the first feature-valid inception. All score windows inherit state and use the same valuation endpoints. Terminal holdings are marked; the separate liquidation estimate applies the declared haircut at the final mark and is not represented as an observed fill. Neither this accounting nor a selected assumed cost grid establishes actual spread, fill, market-impact or financing costs.

The cost-grid sign-change report brackets only adjacent evaluated scenarios with opposite cumulative-difference signs. It makes no interpolation, monotonicity or unique-break-even assertion. An exact zero at a grid point remains visible in the full evaluated grid even though it is not an opposite-sign bracket.

## Timeframes, venues, and uncertainty

`Settings.at_interval` preserves intended clock durations by rounding upward and recalculating annualization. For example the four-hour reference 50/200 becomes hourly 200/800 and daily 9/34; the four-hour warm-up/trailing history 2000/4380 becomes hourly 8000/17520 and daily 334/730. Daily rounding means the resulting filter is not precisely the same continuous-time EMA. Native data gaps also differ. The common matched date window reduces endpoint confounding but does not isolate candle frequency as the only changed factor. The protocol states this limitation. It does not claim that the unavailable earlier hourly selection-phase gate succeeded.

The paired bootstrap receives adaptive-minus-reference net log returns over the identical scored intervals. Blocks use physical days, with common random indices across contrasts/costs in a case. The implementation uses overlapping non-circular moving blocks and truncates the final sampled block to the original sequence length. Mean annualization is a linear scaling of per-bar log differences, not CAGR. Fewer than five physical blocks, or any missing scored interval including the boundary from the previous valuation, makes the interval unavailable. There is no IID fallback. Some short matched-window 60-day sensitivities can therefore be unavailable by design.

The primary approximate summary is the registered 30-day percentile interval for the four-hour Binance adaptive-minus-fixed mean at 25 bps. Comparing its lower endpoint with 0.02 annual log units is a retrospective approximate inference conditional on sufficiently stable weak dependence. Five blocks is a minimum diagnostic convention, not a theorem establishing effective sample size or finite-sample coverage. The resampling does not rerun the research search, remove prior researcher knowledge, prove stationarity, supply simultaneous coverage for all controls/costs/subperiods, or give optional-stopping validity. The protocol and report correctly label secondary intervals as unadjusted exploratory robustness summaries. Any manuscript must preserve these qualifications even if one interval excludes materiality or zero.

Bitstamp BTC/USD uses a separately identified provider and symbol rather than relabeling the Binance BTC/USDT source. It is a dependent Bitcoin robustness exercise with different quote-currency risks and historical candles. It is not an independent asset replication, an arbitrage test, or evidence that USD and USDT are economically interchangeable.

## Second-venue import and independent reconciliation

The [official Bitstamp API documentation](https://www.bitstamp.net/api/) specifies OHLC step in seconds, a limit of 1-1000, a start timestamp and `exclude_current_candle`. The importer uses the declared interval and at most 1000 nominal candles per request, passes only the start boundary, and rejects returned rows outside its exact page window. This avoids relying on the documented end-over-start precedence when both are supplied. The actual returned order is explicitly normalized; duplicate timestamps are rejected rather than deduplicated. Close times are inferred nominal interval endpoints, which is disclosed because the API supplies opening timestamps.

The independent standard-library reconciliation does not call the importer's decoder or candle audit. It verifies raw payload hashes, market identity, contiguous requested page windows, raw timestamp uniqueness and page membership, quarantine row hashes and invalidity, exact raw-to-CSV OHLCV matches, nominal close times and complete normalized boundaries. Every retained normalized row must be visited and every quarantine entry reconciled. Missing raw candles and rows removed by declared quarantine are counted separately. A hash pins locally retrieved bytes; it does not prove the venue's historical data were available without revisions or provide a vendor-published checksum. Raw cache paths are local reproduction dependencies. The review did not assert external authenticity from these hashes.

An additional synthetic check exercised two pages of 1000 and 2 candles, reversed native response order, one missing raw candle and one quarantined zero-volume candle. It retained 1000 candles and independently recovered one raw omission, one quarantine and two total missing grid points. Existing tests also reject wrong markets, duplicate timestamps, out-of-window responses and changed cached raw responses.

## Freeze, attempts, and reproducibility

The freeze checks input identities and audit hashes, computes feature coverage without `run_suite`, and pins the specification, original configuration, code/tests/scripts, Python/NumPy versions, protocols/review/audit documents, CSV/manifest bytes and a real source ZIP. The source archive includes configurations and executable source. The runner verifies the seal and all pinned inputs/documents before the first portfolio calculation, requires an explicit retrospective acknowledgement, and records attempted access before checking that acknowledgement. It records child attempts before each case, saves partial output on failure and retains all declared cases. A later code, protocol or data change must receive a new matching freeze; this review's fingerprints must not be silently described as covering changed code.

The seal is an integrity fingerprint, not a signature or external timestamp. Local users can import the evaluation function directly or construct a new protocol, and an administrator can alter a local ledger. These controls document the intended workflow and detect accidental changes; they do not establish prospective secrecy or protection against an adversarial researcher. The protocol explicitly acknowledges acquisition/coverage inspection, earlier inspected 2024 results and researcher prior knowledge. No stronger holdout claim is justified.

Saved reports, source/data hashes, initial states, selections, base-cost trades and scenario NAV/cash/coin/weight/cost/turnover/attribution arrays support independent recomputation. Counts of prior market accesses are local ledger counts, not a proof that every possible external access was recorded. The synthetic formal guarantees and actual market-cost sensitivities remain separate estimands.

## Verification performed

- Final focused suite: `.venv/Scripts/python.exe -m pytest tests/test_market_study.py tests/test_venues.py -q --basetemp=runs/pytest-agent-market-final` — **17 passed**.
- Supporting engine/config/stats/data/ledger suite: `.venv/Scripts/python.exe -m pytest tests/test_engine.py tests/test_config.py tests/test_stats.py tests/test_data.py tests/test_ledger.py -q --basetemp=runs/pytest-agent-market-inherited` — **110 passed**. Supporting source did not change between this run and the final fingerprint.
- Independent synthetic two-page import/reconciliation check described above — passed; temporary synthetic files were removed.
- No real-data P&L evaluation, new-period portfolio-return inspection, substantive simulation study, or real-data result-driven amendment was performed by this reviewer.

The final runtime was Python **3.13.7**, NumPy **2.5.4**. These tests exercise the stated mechanics and failure paths; passing them is not a mathematical guarantee of market profitability or bootstrap coverage.

## Final reviewed fingerprint

Aggregate `code_hash(root)` (Python source under src/tests/scripts plus pyproject and lock):

`64adfb24513a7f50754b7352fb305a1f6999f77604284d84fb4fcb5ff8893e87`

| File | SHA-256 |
| --- | --- |
| src/quant/market_study.py | 88a6717a66fa1033e595157b0ab47a061e50817e5fae7c5aabad5a2b33a0e69d |
| src/quant/venues.py | 60b92c1930ecb80e9eee163b8305abd3c4577852c16fbb594691d87f617b01a4 |
| scripts/audit_bitstamp_data.py | 38a094953e811a62ba54731dd3954ce4c4c3ce8ddff213f3681a9b5e0b2aa103 |
| tests/test_market_study.py | 3757c0bf36ccff67b4abcb99bae53ffa3724fb6d7e45a5eaf517922eb3d66fc0 |
| tests/test_venues.py | 904a9aa3088e334f2f498db525303534d22b47a8416ef3bddbc2f6a4aac0d911 |
| configs/research/market-study-v1.json | 62ecbff1622c3e399c9d0d4bd0e5d660e9ffa4f145572029e6d0685cdd917e39 |
| docs/publication/market-protocol-v1.md | d9c45ee60c14a25dc5b7a16b87ace4d7602f28c31d7a10fdae82152df6a918f3 |
| src/quant/engine.py | dab857df55fd6940befb052d119b503c319d9bcf5e9874e1eeee23ba39e87203 |
| src/quant/config.py | 32a3bd499679047e32e20198db74466e608d5cd4a8a2ac408a9cd21892f41ec8 |
| src/quant/stats.py | 3882f56f4c8090875f33d5b7725524a701ba6f13a6bbad43590ab60523445497 |
| src/quant/data.py | 6ae084784ebe5f18e070282cba71c08dc5f61af4d2f9ed896ed70671529d74db |
| src/quant/ledger.py | 363ae0cc244c298d9672a29aaf40f896e668e5925da766323bd18d8d205c007d |
| src/quant/publication.py | 327ddf07481c9af63b4dea432aca675cff4387dd33fcba997db4b2fb63bd770a |
| configs/research/btc-trend.toml | df0360d92222ef6b6ce15185e55cc4d2c6bb7f4ef845967d7cde70c71a54d5bb |
| scripts/audit_publication_data.py | db0a4c9c38be9d0f79f731d97d63570b35f1a117972bf53548da6b6708ee9f66 |

The market freeze should pin this review's bytes as a document in addition to the source fingerprints. No fingerprint of this file is embedded in itself.
